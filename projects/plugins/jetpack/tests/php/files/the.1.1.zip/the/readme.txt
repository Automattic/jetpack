=== The ===
Contributors: georgestephanis
Tags: WCPhilly, WCPhilly2011, The, Hipster, Capitalization, Shorttag
Requires at least: 3.6
Tested up to: 4.0
Stable tag: 1.1

Adds a [the] shortcode, that will generate output based on specific parameters.

== Description ==

Based upon an idea developed while walking to the afterparty at WordCamp Philly 2011 by George Stephanis (@Daljo628), John Hawkins (@VegasGeek), Dre Armeda (@DreMeda), and Ben Metcalfe (@DotBen), this plugin adds a shortcode of [the], which replaces the shortcode with either `the`, `The`, `teh`, or `Teh` depending on whether or not the `caps` or `hipster` parameters are set.
