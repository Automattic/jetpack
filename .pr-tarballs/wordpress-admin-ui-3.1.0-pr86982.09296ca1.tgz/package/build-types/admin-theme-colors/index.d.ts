type AdminThemeColors = {
    primary: string;
    background: string;
};
export declare const ADMIN_THEME_COLORS: Map<string, AdminThemeColors>;
/**
 * Reads the active WordPress admin color scheme from the `admin-color-*` body
 * class and returns its primary and background colors. Intended to seed a
 * `ThemeProvider` (`color` prop) so the design system matches the user's chosen
 * admin color scheme.
 *
 * @return The primary and background colors for the active admin color scheme.
 */
export declare function getAdminThemeColors(): AdminThemeColors;
export {};
//# sourceMappingURL=index.d.ts.map