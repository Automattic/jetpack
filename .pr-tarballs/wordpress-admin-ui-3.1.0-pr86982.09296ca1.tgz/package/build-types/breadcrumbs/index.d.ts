import type { BreadcrumbsProps } from './types';
/**
 * Renders a breadcrumb navigation trail. All items except the last one link to
 * their `href`. The last item is the current page and is the page heading.
 *
 * Internal to the package: configured through the `Page` `breadcrumbs` prop.
 */
export declare const Breadcrumbs: ({ items, headingLevel, linkComponent, }: BreadcrumbsProps) => import("react").JSX.Element | null;
export default Breadcrumbs;
//# sourceMappingURL=index.d.ts.map