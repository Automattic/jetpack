import type { NavigationProps } from './types';
/**
 * Renders a horizontal list of links for navigating between the sections of a
 * screen. The item whose `href` matches `currentHref` is marked with
 * `aria-current="page"`.
 *
 * Internal to the package: configured through the `Page` `navigation` prop.
 */
export declare const Navigation: ({ items, currentHref, ariaLabel, linkComponent, className, }: NavigationProps) => import("react").JSX.Element | null;
export default Navigation;
//# sourceMappingURL=index.d.ts.map