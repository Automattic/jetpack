export { default as NavigableRegion } from './navigable-region';
export { default as Page } from './page';
export { getAdminThemeColors } from './admin-theme-colors';
//# sourceMappingURL=index.d.ts.map