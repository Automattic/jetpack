import type { BreadcrumbItem } from '../breadcrumbs/types';
import type { NavigationConfig } from '../navigation/types';
import type { PageComponents } from './types';
export default function Header({ headingLevel, breadcrumbs, badges, visual, title, subTitle, actions, navigation, components, showSidebarToggle, }: {
    headingLevel?: 1 | 2 | 3 | 4 | 5 | 6;
    breadcrumbs?: readonly BreadcrumbItem[];
    badges?: React.ReactNode;
    visual?: React.ReactNode;
    title?: React.ReactNode;
    subTitle: React.ReactNode;
    actions?: React.ReactNode;
    navigation?: NavigationConfig;
    components?: PageComponents;
    showSidebarToggle?: boolean;
}): import("react").JSX.Element;
//# sourceMappingURL=header.d.ts.map