import clsx from "clsx";
import { forwardRef } from "@wordpress/element";
import { jsx } from "react/jsx-runtime";
// packages/admin-ui/src/navigable-region/index.tsx
const NavigableRegion = forwardRef(({ children, className, ariaLabel, as: Tag = "div", ...props }, ref) => {
	return /* @__PURE__ */ jsx(Tag, {
		ref,
		className: clsx("admin-ui-navigable-region", className),
		"aria-label": ariaLabel,
		role: "region",
		tabIndex: "-1",
		...props,
		children
	});
});
NavigableRegion.displayName = "NavigableRegion";
export { NavigableRegion as default };

//# sourceMappingURL=index.mjs.map