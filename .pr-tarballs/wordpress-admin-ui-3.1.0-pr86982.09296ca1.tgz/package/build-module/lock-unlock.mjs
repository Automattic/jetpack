import { __dangerousOptInToUnstableAPIsOnlyForCoreModules } from "@wordpress/private-apis";
// packages/admin-ui/src/lock-unlock.ts
const { lock, unlock } = __dangerousOptInToUnstableAPIsOnlyForCoreModules("I acknowledge private features are not for use in themes or plugins and doing so will break in the next version of WordPress.", "@wordpress/admin-ui");
export { lock, unlock };

//# sourceMappingURL=lock-unlock.mjs.map