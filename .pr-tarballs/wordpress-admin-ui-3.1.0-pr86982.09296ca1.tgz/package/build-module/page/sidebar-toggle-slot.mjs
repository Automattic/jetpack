import { createSlotFill } from "@wordpress/components";
// packages/admin-ui/src/page/sidebar-toggle-slot.tsx
const { Fill: SidebarToggleFill, Slot: SidebarToggleSlot } = createSlotFill("SidebarToggle");
export { SidebarToggleFill, SidebarToggleSlot };

//# sourceMappingURL=sidebar-toggle-slot.mjs.map