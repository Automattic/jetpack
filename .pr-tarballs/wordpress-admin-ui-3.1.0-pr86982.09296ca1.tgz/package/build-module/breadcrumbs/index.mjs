import { _x } from "@wordpress/i18n";
import { Link, Stack, Text } from "@wordpress/ui";
import { jsx, jsxs } from "react/jsx-runtime";
// packages/style-runtime/src/index.ts
const STYLE_HASH_ATTRIBUTE = "data-wp-hash";
/**
* Returns the shared style runtime registry.
*
* The registry is stored on `globalThis` so separately bundled copies of this
* package can coordinate through the same document and style maps.
*
* @return The shared runtime registry.
*/
function getRuntime() {
	const globalScope = globalThis;
	if (globalScope.__wpStyleRuntime) return globalScope.__wpStyleRuntime;
	globalScope.__wpStyleRuntime = {
		documents: /* @__PURE__ */ new Map(),
		styles: /* @__PURE__ */ new Map(),
		injectedStyles: /* @__PURE__ */ new WeakMap()
	};
	if (typeof document !== "undefined") registerDocument(document);
	return globalScope.__wpStyleRuntime;
}
/**
* Checks whether a document already contains a style tag for a hash.
*
* @param targetDocument Document to inspect.
* @param hash           Stable hash for the transformed CSS.
*
* @return Whether the style hash already exists in the document.
*/
function documentContainsStyleHash(targetDocument, hash) {
	if (!targetDocument.head) return false;
	for (const style of targetDocument.head.querySelectorAll(`style[${STYLE_HASH_ATTRIBUTE}]`)) if (style.getAttribute(STYLE_HASH_ATTRIBUTE) === hash) return true;
	return false;
}
/**
* Injects a registered style into a document, unless that document already
* contains a style tag for the same hash.
*
* @param targetDocument Document to inject the style into.
* @param hash           Stable hash for the transformed CSS.
* @param css            CSS text to inject.
*/
function injectStyle(targetDocument, hash, css) {
	if (!targetDocument.head) return;
	const runtime = getRuntime();
	let injectedStyles = runtime.injectedStyles.get(targetDocument);
	if (!injectedStyles) {
		injectedStyles = /* @__PURE__ */ new Set();
		runtime.injectedStyles.set(targetDocument, injectedStyles);
	}
	if (injectedStyles.has(hash)) return;
	if (documentContainsStyleHash(targetDocument, hash)) {
		injectedStyles.add(hash);
		return;
	}
	const style = targetDocument.createElement("style");
	style.setAttribute(STYLE_HASH_ATTRIBUTE, hash);
	style.appendChild(targetDocument.createTextNode(css));
	targetDocument.head.appendChild(style);
	injectedStyles.add(hash);
}
/**
* Registers a document as a style injection target.
*
* Existing registered styles are replayed into the document immediately.
* Documents are reference-counted so multiple providers can safely register the
* same document without one cleanup removing it while another registration is
* still active.
*
* @param targetDocument Document to receive registered styles.
* @return Cleanup function that unregisters this document registration.
*/
function registerDocument(targetDocument) {
	const runtime = getRuntime();
	runtime.documents.set(targetDocument, (runtime.documents.get(targetDocument) ?? 0) + 1);
	for (const [hash, css] of runtime.styles) injectStyle(targetDocument, hash, css);
	return () => {
		const count = runtime.documents.get(targetDocument);
		if (count === void 0) return;
		if (count <= 1) {
			runtime.documents.delete(targetDocument);
			return;
		}
		runtime.documents.set(targetDocument, count - 1);
	};
}
/**
* Registers a style and injects it into all registered documents.
*
* The hash is used as the deduplication key, so calling this repeatedly with
* the same hash will not add duplicate style tags to a document.
* Registered styles are retained for the lifetime of the page so they can be
* replayed into documents that are registered later.
*
* @param hash Stable hash for the transformed CSS.
* @param css  CSS text to inject.
*/
function registerStyle(hash, css) {
	const runtime = getRuntime();
	runtime.styles.set(hash, css);
	for (const targetDocument of runtime.documents.keys()) injectStyle(targetDocument, hash, css);
}
// packages/admin-ui/src/breadcrumbs/style.module.css
if (typeof process === "undefined" || process.env.NODE_ENV !== "test") registerStyle("ec86bbdb7d", ".b2a63149563107a4__list{list-style:none;margin:0;padding:0}.b2a63149563107a4__list>li{flex-shrink:0;margin:0}.b2a63149563107a4__list>li:last-child{flex-shrink:1;min-width:0}._92025c5301c05bb2__current{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.b4c6b52039b39e54__separator{color:var(--wpds-color-stroke-surface-neutral,#dbdbdb);margin:0 var(--wpds-dimension-gap-sm,8px);user-select:none}");
var style_module_default = {
	"list": "b2a63149563107a4__list",
	"current": "_92025c5301c05bb2__current",
	"separator": "b4c6b52039b39e54__separator"
};
// packages/admin-ui/src/breadcrumbs/index.tsx
/**
* Renders a breadcrumb navigation trail. All items except the last one link to
* their `href`. The last item is the current page and is the page heading.
*
* Internal to the package: configured through the `Page` `breadcrumbs` prop.
*/
const Breadcrumbs = ({ items, headingLevel, linkComponent }) => {
	if (!items.length) return null;
	const LinkComponent = linkComponent ?? "a";
	const HeadingTag = `h${headingLevel}`;
	const precedingItems = items.slice(0, -1);
	const lastItem = items[items.length - 1];
	if (process.env.NODE_ENV !== "production") {
		const invalidItem = precedingItems.find((item) => typeof item.href !== "string");
		if (invalidItem) throw new Error(`Breadcrumbs: item "${invalidItem.label}" is missing an \`href\` prop. All items except the last one must have an \`href\` prop.`);
	}
	return /* @__PURE__ */ jsx("nav", {
		"aria-label": _x("Breadcrumbs", "aria label"),
		children: /* @__PURE__ */ jsxs(Stack, {
			render: /* @__PURE__ */ jsx("ul", {}),
			direction: "row",
			align: "center",
			className: style_module_default.list,
			children: [precedingItems.map((item, index) => /* @__PURE__ */ jsxs("li", { children: [/* @__PURE__ */ jsx(Text, {
				variant: "body-lg",
				render: /* @__PURE__ */ jsx(Link, {
					tone: "neutral",
					render: /* @__PURE__ */ jsx(LinkComponent, { href: item.href })
				}),
				children: item.label
			}), /* @__PURE__ */ jsx(Text, {
				variant: "body-lg",
				"aria-hidden": "true",
				className: style_module_default.separator,
				children: "/"
			})] }, index)), /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Text, {
				variant: "heading-lg",
				render: /* @__PURE__ */ jsx(HeadingTag, {}),
				className: style_module_default.current,
				children: lastItem.label
			}) })]
		})
	});
};
export { Breadcrumbs, Breadcrumbs as default };

//# sourceMappingURL=index.mjs.map